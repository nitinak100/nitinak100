<form method="post" action="register.php">
  <label for="name">Name:</label>
  <input type="text" id="name" name="name"><br>
  <label for="mobile">Mobile Number:</label>
  <input type="text" id="mobile" name="mobile"><br>
  <label for="email">Email Address:</label>
  <input type="email" id="email" name="email"><br>
  <label for="address">Address:</label>
  <textarea id="address" name="address"></textarea><br>
  <input type="submit" value="Register">
</form>