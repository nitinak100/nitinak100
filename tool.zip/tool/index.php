<!DOCTYPE html>
<html>
<head>
	<title>Chart.js Sales Report</title>
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
	<canvas id="myChart"></canvas>
	<script>
		var ctx = document.getElementById('myChart').getContext('2d');
		var salesData = {
			labels: [],
			data: []
		};
		fetch('/get_sales_by_state.php')
			.then(response => response.json())
			.then(data => {
				data.forEach(row => {
					salesData.labels.push(row.state_name);
					salesData.data.push(row.total_sales);
				});

				var chart = new Chart(ctx, {
					type: 'bar',
					data: {
						labels: salesData.labels,
						datasets: [{
							label: 'Total Sales',
							data: salesData.data,
							backgroundColor: 'rgba(54, 162, 235, 0.5)',
							borderColor: 'rgba(54, 162, 235, 1)',
							borderWidth: 1
						}]
					},
					options: {
						scales: {
							yAxes: [{
								ticks: {
									beginAtZero: true
								}
							}]
						}
					}
				});
			});
	</script>
</body>
</html>
