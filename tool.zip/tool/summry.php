<!DOCTYPE html>
<html>
<head>
	<title>Sales Summary</title>
</head>
<body>
	<h1>Sales Summary</h1>
	<table>
		<tr>
			<th>Total Sales</th>
			<th>Total Sales Amount</th>
			<th>First Sale Date</th>
			<th>Last Sale Date</th>
		</tr>
		<?php
			// Connect to the database
			$conn = mysqli_connect('localhost', 'username', 'password', 'sales_data');

			// Execute the SQL query
			$sql = "SELECT 
					  COUNT(*) as total_sales,
					  SUM(sales_amount) as total_sales_amount,
					  MIN(sale_date) as first_sale_date,
					  MAX(sale_date) as last_sale_date
					FROM sales";
			$result = mysqli_query($conn, $sql);

			// Display the results
			if ($row = mysqli_fetch_assoc($result)) {
				echo '<tr>';
				echo '<td>' . $row['total_sales'] . '</td>';
				echo '<td>' . $row['total_sales_amount'] . '</td>';
				echo '<td>' . $row['first_sale_date'] . '</td>';
				echo '<td>' . $row['last_sale_date'] . '</td>';
				echo '</tr>';
			}

			// Close the database connection
			mysqli_close($conn);
		?>
	</table>
</body>
</html>
