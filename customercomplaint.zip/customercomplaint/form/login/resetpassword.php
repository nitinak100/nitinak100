<form action="resetpassword.php" method="post">
  <label for="email">Email:</label>
  <input type="email" id="email" name="email" required>
  <br>
  <input type="submit" value="Reset Password">
</form>

<?php
// Retrieve the email from the form
$email = $_POST['email'];

// Connect to the database
$conn = mysqli_connect("host", "username", "password", "database");

// Check if the email is associated with a customer in the database
$query = "SELECT * FROM customers WHERE email = '$email'";
$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result) > 0) {
  // Generate a random password reset token
  $token = bin2hex(random_bytes(16));

  // Store the token in the database along with the customer's email address and a timestamp
  $query = "UPDATE customers SET reset_token = '$token', reset_timestamp = CURRENT_TIMESTAMP WHERE email = '$email'";
  $result = mysqli_query($conn, $query);

  // Send an email to the customer's email address with a link that includes the password reset token
  $link = "http://example.com/reset_password.php?token=$token";
  $message = "Please click the link to reset your password: $link";
  mail($email, "Password Reset", $message);

  echo "An email has been sent to $email with instructions on how to reset your password.";
} else {
  echo "Invalid email address.";
}

mysqli_close($conn);
?>
