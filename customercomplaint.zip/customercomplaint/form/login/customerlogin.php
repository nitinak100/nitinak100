<form action="login.php" method="post">
  <label for="email">Email:</label>
  <input type="email" id="email" name="email" required>
  <br>
  <label for="password">Password:</label>
  <input type="password" id="password" name="password" required>
  <br>
  <input type="submit" value="Login">
</form>

<?php
session_start();

// Retrieve the email and password from the form
$email = $_POST['email'];
$password = $_POST['password'];

// Connect to the database
$conn = mysqli_connect("localhost", "shardul", "123", "shardul");

// Check if the email and password match a user in the database
$query = "SELECT * FROM customers WHERE email = '$email'";
$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result) > 0) {
  $row = mysqli_fetch_assoc($result);
  $hash = $row['password'];
  $status = $row['status'];
  if($status != 1) {
    echo "Your account is not active";
  } else {
    if(password_verify($password, $hash)) {
      // Start a session and redirect to a secure page
      $_SESSION['email'] = $email;
      header("Location: secure_page.php");
    } else {
      // Display an error message
      echo "Invalid email or password";
    }
  }
} else {
  // Display an error message
  echo "Invalid email or password";
}

mysqli_close($conn);
?>
