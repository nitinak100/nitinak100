<?php
// Connect to the database
$conn = mysqli_connect('localhost', 'shardul', '123', 'shardul');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get data from the form
$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$address = $_POST['address'];

// Insert data into the database
$sql = "INSERT INTO customers (name, mobile, email, address)
VALUES ('$name', '$mobile', '$email', '$address')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
