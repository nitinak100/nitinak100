<?php
// Connect to the database
$conn = mysqli_connect('localhost', 'root', ' ', 'sales_data');

// Retrieve the sales data by state
$sql = "SELECT s.state, sum(s.sales_amount) as total_sales
        FROM sales s
        GROUP BY s.state";
$result = mysqli_query($conn, $sql);

// Convert the result set to a JSON object
$data = array();
while ($row = mysqli_fetch_assoc($result)) {
	$data[] = $row;
}
echo json_encode($data);

// Close the database connection
mysqli_close($conn);
?>
