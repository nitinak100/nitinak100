<link rel="stylesheet" type="text/css" href="sub.css">
<form action="submitcomplaint.php" method="post" enctype="multipart/form-data">
  <label for="name">Name</label>
  <input type="text" id="name" name="name" required><br>
  
  <label for="email">Email</label>
  <input type="email" id="email" name="email" required><br>


  <label for="mobilenumber">Mobile Number</label>
  <input type="number" id="mobilenumber" maxlength="10" name="mobilenumber" required><br>
 
  
  <label for="complaint">Complaint</label>
  <textarea id="complaint" name="complaint"  required  ></textarea><br>


  <label for="image">Upload Image</label>
  <input type="file" id="image" name="image" accept="image/*" ><br>
  
  <input type="submit" value="Submit">
</form>


<?php
error_reporting(0); 

$name = $_POST['name'];
$email = $_POST['email'];
$complaint = $_POST['complaint'];
$mobilenumber = $_POST['mobilenumber'];

//Validation
if (empty($name) || empty($email) || empty($mobilenumber) || empty($complaint)) {
    echo "All fields are required";
    exit;
}

//Handle uploaded image
$image = $_FILES['image'];
$image_name = $image['name'];
$image_tmp = $image['tmp_name'];
$image_size = $image['size'];
$image_error = $image['error'];

$allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');
$image_extension = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));

if ($image_error !== UPLOAD_ERR_NO_FILE) {
    if (!in_array($image_extension, $allowed_extensions)) {
        echo 'Invalid file type';
        exit;
    }

    if ($image_error === 0) {
        $new_image_name = uniqid('', true) . "." . $image_extension;
        $image_destination = 'compimg/' . $new_image_name;

        if (!move_uploaded_file($image_tmp, $image_destination)) {
            echo 'Error: ' . $_FILES['image']['error'];
            exit;
        }
    }
}

// Connect to the database
$conn = mysqli_connect("localhost", "shardul", "123", "shardul");

$query = "INSERT INTO complaints (name, email, mobilenumber, complaint, image) VALUES ('$name', '$email', '$mobilenumber', '$complaint', '$image_destination')";
mysqli_query($conn, $query);

echo 'Complaint submitted successfully';
?>