-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 08, 2023 at 04:23 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sales_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `indian_states`
--

DROP TABLE IF EXISTS `indian_states`;
CREATE TABLE IF NOT EXISTS `indian_states` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `indian_states`
--

INSERT INTO `indian_states` (`id`, `state_name`) VALUES
(1, 'Maharashtra'),
(2, 'Kerala'),
(3, 'Tamil Nadu'),
(4, 'Uttar Pradesh');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
CREATE TABLE IF NOT EXISTS `sales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `sales_amount` decimal(10,2) NOT NULL,
  `state` varchar(255) NOT NULL,
  `sale_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `product_name`, `sales_amount`, `state`, `sale_date`) VALUES
(1, 'Product A', '100.00', 'New York', '2022-01-01'),
(2, 'Product B', '150.50', 'California', '2022-01-02'),
(3, 'Product C', '75.00', 'Texas', '2022-01-03'),
(4, 'Product D', '200.00', 'Florida', '2022-01-04'),
(5, 'Product E', '50.25', 'New York', '2022-01-05'),
(6, 'Product F', '300.75', 'California', '2022-01-06'),
(7, 'Product G', '125.00', 'Texas', '2022-01-07'),
(8, 'Product H', '75.50', 'Florida', '2022-01-08'),
(9, 'Product I', '175.25', 'New York', '2022-01-09'),
(10, 'Product J', '250.00', 'California', '2022-01-10');

-- --------------------------------------------------------

--
-- Table structure for table `sales_by_state`
--

DROP TABLE IF EXISTS `sales_by_state`;
CREATE TABLE IF NOT EXISTS `sales_by_state` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state_id` int NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `sales_amount` decimal(10,2) NOT NULL,
  `sale_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `state_id` (`state_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
