<link rel="stylesheet" type="text/css" href="comp.css">

<?php
  // Include the database connection file
  $conn = mysqli_connect("localhost", "shardul", "123", "shardul");


  // Define the query to retrieve all complaints
  $query = "SELECT id, name, email, mobilenumber, complaint, image, created_at FROM complaints";

  // Execute the query and store the result
  $result = mysqli_query($conn, $query);

  // Check if the query was successful
  if($result){
    // Fetch all the complaints as an associative array
    $complaints = mysqli_fetch_all($result, MYSQLI_ASSOC);
  }else{
    echo "Error: ". mysqli_error($conn);
  }
?>

<!DOCTYPE html>
<html>
<head>
  <title>View Complaints</title>
</head>
<body>
<table>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Email</th>
      <th>Mobile Number</td>
      <th>Complaint</th>
      <th>Image</th>
      <th>Date</th>
    </tr>
    <?php foreach($complaints as $complaint): ?>
      <tr>
        <td><?php echo $complaint['id']; ?></td>
        <td><?php echo $complaint['name']; ?></td>
        <td><?php echo $complaint['email']; ?></td>
        <td><?php echo $complaint['mobilenumber']; ?></td>
         <td><?php echo $complaint['complaint']; ?></td>
       <!-- <td><a href="<?php echo $complaint['image']; ?>" target="_blank"><button class="view-image-btn">View Image</button></a></td> -->
        <td><a href="<?php echo $complaint['image']; ?>"><button class="view-image-btn">View Image</button></a></td>

        <td><?php echo $complaint['created_at']; ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</body>
</html>


<script>

$(window).load(function () {
    $(".view-image-btn").click(function(){
       $('.view-image-btn').show();
    });
    $('.hover_bkgr_fricc').click(function(){
        $('.view-image-btn').hide();
    });
    $('.popupCloseButton').click(function(){
        $('.view-image-btn').hide();
    });
});


</script>
