CREATE DATABASE sales_data;
USE sales_data;

CREATE TABLE sales (
  id INT(11) NOT NULL AUTO_INCREMENT,
  product_name VARCHAR(255) NOT NULL,
  sales_amount DECIMAL(10, 2) NOT NULL,
  state VARCHAR(255) NOT NULL,
  sale_date DATE NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE indian_states (
  id INT(11) NOT NULL AUTO_INCREMENT,
  state_name VARCHAR(255) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE sales_by_state (
  id INT(11) NOT NULL AUTO_INCREMENT,
  state_id INT(11) NOT NULL,
  product_name VARCHAR(255) NOT NULL,
  sales_amount DECIMAL(10, 2) NOT NULL,
  sale_date DATE NOT NULL,
  PRIMARY KEY (id),
  FOREIGN KEY (state_id) REFERENCES indian_states(id)
);


-------------

<?php
// Replace the database credentials with your own
$host = 'localhost';
$username = 'root';
$password = 'password';
$dbname = 'sales_data';

// Connect to the database
$conn = mysqli_connect($host, $username, $password, $dbname);

// Check if the connection is successful
if (!$conn) {
  die('Connection failed: ' . mysqli_connect_error());
}

// Calculate total sales
$query = "SELECT SUM(sales_amount) AS total_sales FROM sales";
$result = mysqli_query($conn, $query);
$total_sales = mysqli_fetch_assoc($result)['total_sales'];

// Determine top selling product
$query = "SELECT product_name, MAX(sales_amount) AS max_sales FROM sales GROUP BY product_name ORDER BY max_sales DESC LIMIT 1";
$result = mysqli_query($conn, $query);
$top_selling_product = mysqli_fetch_assoc($result)['product_name'];

// Retrieve sales data by Indian state
$query = "SELECT i.state_name, s.product_name, SUM(s.sales_amount) AS total_sales FROM sales s JOIN indian_states i ON s.state=i.state_name GROUP BY i.state_name, s.product_name";
$result = mysqli_query($conn, $query);
$sales_by_state = array();
while ($row = mysqli_fetch_assoc($result)) {
  $state = $row['state_name'];
  $product = $row['product_name'];
  $sales = $row['total_sales'];
  if (!isset($sales_by_state[$state])) {
    $sales_by_state[$state] = array();
  }
  $sales_by_state[$state][$product] = $sales;
}

// Close the database connection
mysqli_close($conn);
?>


